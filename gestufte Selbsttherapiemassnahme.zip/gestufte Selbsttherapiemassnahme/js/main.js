function kameramove() {
    document.querySelector("#cam").emit("movecam_1");
}
